---
name: Bug report / 錯誤回報
about: You must follow this template or I will close this directly. / 請務必填寫此模板，否則我會直接關閉。
title: ''
labels: ''
assignees: ''

---

<!-- Please search before opening new issue, or I will simply close it if it is asked before. -->
<!-- 發 issue 前請先搜尋過，如果是重複的問題我就會直接關閉 -->

# Bug Description / 問題描述

<!-- Describe it as detailed as possible -->
<!-- 請詳細描述 -->

# Environment / 環境

* Browser version / 瀏覽器版本:
* OS version / 作業系統版本:
