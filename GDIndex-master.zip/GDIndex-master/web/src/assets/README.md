`epub-reader.html` is the inlined version of https://github.com/maple3142/epubjs-reader, and the tool I used https://github.com/remy/inliner
