module.exports = {
	plugins: {
		autoprefixer: {},
	},
}
